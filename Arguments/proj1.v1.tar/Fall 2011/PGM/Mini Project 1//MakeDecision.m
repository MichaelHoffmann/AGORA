%% Decision Making
%%
%% INPUT: a structure "info" containing the following field
%%        stage, pot, cur_pos, cur_pot, first_pos, board card,
%%        hole_card, active, paid, history, su_info, oppo_model
%% OUTPUT: an integer from 1 to 3 indicating:
%%         1: CALL or CHECK
%%         2: BET or RAISE
%%         3. FOLD

%% We provide some auxiliary probability tables, see section 3.4 
%% in the write-up. If you use BNT by Kevin Murphy, please check
%% sample BNT code student_BNT.m in T-Square to see how to use it.
%%
%% Some zero entrie do not really mean zero probability, instead
%% they mean states we do not care about because they can not
%% contribute to any effective hand category in the showdown

%% Table 1: Prior probability of final categories given 7 cards

%%  Busted          0.1728
%%  One Pair        0.438
%%  Two Pair        0.2352
%%  3 of a Kind     0.0483
%%  Straight        0.048
%%  Flush           0.0299
%%  Full House      0.0255
%%  4 of a Kind     0.0019
%%  Straight Flush	0.0004


%% Table 2: Straight and Flush CPT from flop (given two draws)
%%                  SF      Flush	Straight
%%	SFO3            0.0028	0.0389	0.0416
%%	SFO4            0.0842	0.2784	0.2414
%%	SFI4            0.0426	0.3145	0.1249
%%	F3              0       0.0416	0
%%	F4              0       0.3497	0
%%	SO3             0       0       0.0444
%%	SO4             0       0       0.3145
%%	SI4             0       0       0.1647
%%	SF03 & F4       0.0028	0.3469	0.0416
%%	SF03 & SI4      0.0028	0.0389	0.1360
%%	SF03 & SO4      0.0028	0.0389	0.2784
%%	SI4 & F3        0       0.0416	0.1647
%%	SI4 & F4        0       0.3497	0.1249
%%	SO3 & F3        0    	0.0416	0.0416
%%	SO3 & F4        0    	0.3497	0.0250
%%	SO4 & F3        0    	0.0416	0.2756
%%	SO4 & F4        0    	0.3497	0.2414



%% Table 3: N of a Kind CPT from flop (given two draws)

%%              K4      K3K2	K3      K2K2	K2	Junk
%%	K3K2	0.0435	0.9565  0           0   	0	0
%%	K3      0.0426	0.1249	0.8325       0       0	0
%%	K2K2	0.0019	0.1619	0.0000     	0.8362  0	0
%%	K2      0.0009	0.0250	0.0666	0.3000	0.6075	0
%%	Junk	0.0000	0.0000	0.0139    0.0832	0.4440	0.4589



%% Table 4: Straight and Flush CPT from turn (given one draw)

%%              SF      Flush	Straight
%%	SFO4	0.0435	0.1522	0.1739
%%	SFI4	0.0217	0.1739	0.0870
%%	F4      0       0.1957	0
%%	SO4     0       0       0.1739
%%	SI4     0       0       0.0870



%% Table 5: N of a Kind CPT from turn (given one draw)

%%              K4          K3K2    K3      K2K2	K2	Junk
%%	K3K2	0.0217      0.9783  0       0      	0	0
%%	K3      0.0217      0.1960  0.7823  0		0	0
%%	K2K2	0.0000      0.0870  0       0.913       0	0
%%	K2      0.0000      0       0.0435  0.2609	0.6956	0
%%	Junk	0.0000      0       0       0    	0.3910	0.609

function decision = MakeDecision(info)
    if (info.stage == 0)
        decision = MakeDecisionPreFlop(info);
    else
        decision = MakeDecisionPostFlop(info);
    end
end


function decision = MakeDecisionPreFlop(info)
    global agent_pos
    distribution = [];
    %win_prob = PredictWin(distribution);
    %% The following is just a sample of randomly generating different
    %% decisions. Please comment them after you finish your part.
    
    %if(info.cur_pos == agent_pos)
    %    decision = 1;
    %else
        num = floor(rand(1)*100);
        if (num <= 60)
            decision = 1;
        elseif (num <= 90)
            decision = 2;
        else
            decision = 3;
        end 
    %end   
end

function [type highcard] = final_type(v)
    [ct highcard_ct] = cardtype(v);
    [sf highcard_sf] = sftype(v);
    
    if (ct <= 3)
        type = ct;
        highcard = highcard_ct;
    end
    
    if (sf == 8)
        type = 4; % straight
        highcard = highcard_sf;
    end
    
    if (sf == 5)
        type = 5; % flush
        highcard = highcard_sf;
    end
    
    if (ct == 4)
        type = 6; % full house
        highcard = highcard_ct;
    end
    
    if (ct == 5)
        type = 7; % four of a kind
        highcard = highcard_ct;
    end
    
    if (sf == 1)
        type = 8; % straight flush
        highcard = highcard_sf;
    end
    
end
 
function decision = MakeDecisionPostFlop(info)
    global agent_pos
    global prior_sf prior_k
    global pre_flop flop turn river
    global sf_1d sf_2d k_1d k_2d
    global N
    global CALL RAISE FOLD
    
    if(info.cur_pos == agent_pos)
        %% get the probability distribution table entries
        %% for K and S for the agent
        %distribution = [];
        %% For oponnents use the prior distribution
        %% Form them as a distribution and pass it to oponent_modeling
        %% Put all matrices into a cell array and pass it to the funciton
        distribution = {};
        
        hand = [info.hole_card info.board_card];
        kofakind_type = cardtype(hand) + 1;
        sf_type = sftype(hand) + 1;
        
        if(info.stage == flop)
            AFH_SF = sf_2d(sf_type, :);
            AFH_K = k_2d(kofakind_type, :);
        elseif(info.stage == turn)
            AFH_SF = sf_1d(sf_type, :);
            AFH_K = k_1d(kofakind_type, :);
        elseif(info.stage == river)
           AFH_SF = zeros(1,4);
           AFH_K = zeros(1,6);
           [type, highcard] = final_type([info.hole_card info.board_card]);
          
          if(type <= 3 && type >=1)
              AFH_K(6-type)=1;
          elseif(type == 4)
              AFH_SF(3) = 1;
          elseif(type == 5)
              AFH_SF(2) = 1;
          elseif(type == 6)
              AFH_K(2) = 1;
          elseif(type == 7)
              AFH_K(1) = 1;
          elseif(type == 8)
              AFH_SF(1) = 1;
          elseif(type == 0)
              AFH_SF(4) = 1;
              AFH_K(6) = 1;
          end
        end
        
        distribution = cell(N, 2);
        distribution{1,1} = AFH_SF;
        distribution{1,2} = AFH_K;
        
        for i = 2:N
            if(info.active(i) == 1)
                distribution{i,1} = prior_sf;
                distribution{i,2} = prior_k;
            end
        end

        win_prob = PredictWin(distribution);
        
        %write code for calculating utility
        %current bet on the table
        T  = 0.2;
        Bt = info.cur_pot - info.paid(agent_pos);
        Na = sum(info.active);
        if(Bt ~= 0)
          pot_odds = Bt / (Bt + info.cur_pot);
          
          if(win_prob > ( (Bt + 1)/(info.cur_pot+ Na + Bt + 1) - T) )
              decision = RAISE;
          elseif(win_prob > pot_odds - T)
              decision = CALL;
          elseif(win_prob < 0.2)
              decision = FOLD;
          else
               decision = CALL;
          end
        else
            decision = CALL;
        end
        analysis = fopen('analysis.txt', 'a');
        %fprintf(analysis,'%d\n',decision);
        fclose(analysis);
        else
        num = floor(rand(1)*100);
        if (num <= 60)
            decision = 1;
        elseif (num <= 90)
            decision = 2;
        else
            decision = 3;
        end
    end
end

function win_prob = PredictWin(distribution)
    global N
    odds_against_nth = [];
    %calculate the four tables
    %sum up all the cases where the agent winss
    %model is as follows: four tables representing sets of events
    %mutually exclusive and exhaustive
    %probability of winning is given by the sum of winning in the four
    %cases.
    
    SFa = distribution{1,1};
    Ka = distribution{1,2};
    
    for i=2:N
        if(length(distribution{i,1}) == length(SFa))
        %calculate the four tables
        SFo = distribution{i,1};
        Ko = distribution{i,2};
        
        pwin = 0;
        
        %SFa_SFo
        SFa_SFo = (SFa' * SFo)./4;
        
        pwin = sum(sum(triu(SFa_SFo),1));
        
        %SFa_Ko
        SFa_Ko = (SFa' * Ko) ./ 4;
        pwin = pwin + sum(SFa_Ko(1,:));
        %flush has more value than all the k of a kind except for 
        %full house and 4 of a kind
        pwin = pwin + sum(SFa_Ko(2,:)) - SFa_Ko(2,1) - SFa_Ko(2,2);
        pwin = pwin + sum(SFa_Ko(3,:)) - SFa_Ko(3,1) - SFa_Ko(3,1);
        
        %Ka_Ko
        Ka_Ko = (Ka' * Ko) ./ 4;
        pwin = pwin + sum(sum(triu(Ka_Ko,1)));
        
        %Ka_SFo
        Ka_SFo = (Ka' * SFo) ./ 4;
        pwin = pwin + sum(Ka_SFo(1,:)) - Ka_SFo(1,1);
        pwin = pwin + sum(Ka_SFo(2,:)) - Ka_SFo(2,1);
        
        odds_against_nth = [odds_against_nth pwin];
        end
    end    
   %odds_against_nth
   % win_prob = 1;
   %for i = 1:length(odds_against_nth)
   %   win_prob = win_prob * odds_against_nth(i);
   %end
  %win_prob = min(odds_against_nth);
  win_prob = mean(odds_against_nth);    
end