%% Beyasian Texas Hold'Em
%% CS8803 PGM
%% Fall 2011
%% David Tsai (caihsiaoster@gatech.edu)
%%
%% Please read write-up and readme.txt before you start coding!
%%
%% INSTRUCTIONS:
%% Hand Model : Fill in the missing code in StageUpdater.m
%% Betting Strategy : Fill in the missing code in MakeDecision.m
%% Opponent Modeling : Fill in the missing code in UpdateOpponent.m


function poker_main()

    clear all;
    global CARDnames VALnames SUITnames FHnames Knames SFnames 
    global agent_pos
    global prior sf_2d sf_1d k_2d k_1d 
    global pre_flop flop turn river
    global prior_sf prior_k
    global N
    global CALL RAISE FOLD
    global analyis
    prior_sf = [0.0004 0.0299 0.048 0.9217];
    prior_k = [0.0019 0.0255 0.0483 0.2352 0.438 0.2511];
    
    pre_flop = 0; flop = 1; turn = 2; river = 3;
    
    %right now, it's just fixed. Later, change it according
    % to Poker rules
    agent_pos = 1;

%%   0 -- Junk
%%   1 -- SF
%%   2 -- SFO4
%%   3 -- SFO3
%%   4 -- SFI4
%%   5 -- F
%%   6 -- F4
%%   7 -- F3
%%   8 -- S
%%   9 -- SO4
%%   10 -- SO3
%%   11 -- SI4
%%   12 -- SFO3 & F4
%%   13 -- SFO3 & SI4
%%   14 -- SFO3 & SO4
%%   15 -- SI4 & F3
%%   16 -- SI4 & F4
%%   17 -- SO3 & F3
%%   18 -- SO3 & F4
%%   19 -- SO4 & F3
%%   20 -- SO4 & F4
%%

%%according to values returned by sftype.m
    sf_2d = [
         0         0         0    1.0000
    1.0000         0         0         0
    0.0842    0.2784    0.2414    0.3960
    0.0028    0.0389    0.0416    0.9167
    0.0426    0.3145    0.1249    0.5180
         0    1.0000         0         0
         0    0.3497         0    0.6503
         0    0.0416         0    0.9584
         0         0    1.0000         0
         0         0    0.3145    0.6855
         0         0    0.0444    0.9556
         0         0    0.1647    0.8353
    0.0028    0.3469    0.0416    0.6087
    0.0028    0.0389    0.1360    0.8223
    0.0028    0.0389    0.2784    0.6799
         0    0.0416    0.1647    0.7937
         0    0.3497    0.1249    0.5254
         0    0.0416    0.0416    0.9168
         0    0.3497    0.0250    0.6253
         0    0.0416    0.2756    0.6828
         0    0.3497    0.2414    0.4089
         ];

    k_2d = [
	0.0000    0.0000    0.0139    0.0832    0.4440    0.4589
	0.0009    0.0250    0.0666    0.3000    0.6075    0
	0.0019    0.1619    0.0000    0.8362  0    0
	0.0426    0.1249    0.8325    0   	0    0
	0.0435    0.9565  0   	0  	 0    0
    0           0        0           0           0       0
];

sf_1d = [
         0         0         0    1.0000
    1.0000         0         0         0
    0.0435    0.1522    0.1739    0.6304
         0         0         0    1.0000
    0.0217    0.1739    0.0870    0.7174
         0    1.0000         0         0
         0    0.1957         0    0.8043
         0         0         0    1.0000
    1.0000         0         0         0
         0         0    0.1739    0.8261
         0         0         0    1.0000
         0         0    0.0870    0.9130
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
         0         0         0    1.0000
        ];
  
  k_1d = [
	0.0000  	0   	0   	0   	 0.3910    0.609
	0.0000  	0   	0.0435  0.2609    0.6956    0
	0.0000  	0.0870  0   	0.913   	0    0
	0.0217  	0.1960  0.7823  0   	 0    0
    0.0217  	0.9783  0   	0 		 0    0
    1.0         0       0       0        0    0
    ];
    
    N = 2;  % number of players
    GAME_NUM = 10;  % number of games - 25
    pos = 0;
    RAISE_LIMIT = 3;  % maximum number of raises each round
    SBU = 10;
    SB = SBU / 2;
    BB = SBU;
    COIN = 5000;  % money each player initially has
    money = ones(1,N) * COIN;  % money each player currently has
    oppo_model = cell(N,1);  % opponent model parameters

    CALL = 1;  %% CALL or CHECK
    RAISE = 2; %% BET or RAISE
    FOLD = 3;  %% FOLD
    
  
    % Cell arrays of strings for pretty printing hands and categories
    FHnames = {'Junk' 'K2' 'K2K2' 'K3' 'S' 'F' 'K3K2' 'K4' 'SF'};
    Knames = {'NP' 'K2' 'K2K2' 'K3' 'K3K2' 'K4'};
    SFnames = {'J' 'SF' 'SFO4' 'SFO3' 'SFI4' 'F' 'F4' 'F3' 'S' 'SO4' 'SO3' 'SI4' 'SFO3-F4' 'SFO3-SI4' 'SFO3-SO4' 'SI4-F3' 'SI4-F4' 'SO3-F3' 'SO3-F4' 'SO4-F3' 'SO4-F4'};
    MakeCardNames();

    history = struct('showdown',[],'board',[],'hole',[],'bet',[]);
    history_pre = history;
    
    % fid = fopen('record.txt','w');
    fid = 1;
    fprintf(fid, 'Game started!\n');
    %analysis = fopen('analysis.txt','w');
    % main loop
    for round = 1:GAME_NUM
        disp(round);
        str = '*************** Game ';
        str = [str, num2str(round)];
        str = [str, ' ******************'];
        fprintf(fid, '\n\n%s\n', str);
        % initialization
        pos = mod(pos+1,N);
        first_pos = pos + 1;
        second_pos = first_pos + 1;
        if (second_pos > N)
            second_pos = 1;
        end
        pot = 0;
        hole_card = zeros(N,2);
        board_card = ones(1,5)*-1;
        all_cards = randperm(52) - 1;  % see readme for card representation
        cur = 1;  % current card pointer when dealing cards
        active = ones(1,N); % binary vector indicating if a player is
                            % still alive or already folded

        %--------------------  Pre-Flop Stage -------------------------
        % deal hole cards
        for i = 1:N
            hole_card(i,1) = all_cards(cur);
            cur = cur + 1;
            hole_card(i,2) = all_cards(cur);
            cur = cur + 1;
        end

        % bet
        start = true;
        cur_pos = first_pos;
        cur_pot = 0; % pot in this round
        raise_num = 0; % num of raises in this round
        paid = zeros(1,N); % money each player already paid in this round
        end_pos = -1;
        tmp_bet = zeros(1,N);
        fprintf(fid, '\nBeginning: \n\t');
        PrintGameInfo(fid,active,money,pot,0,hole_card);
        
        su_info = []; % stage_updater info
        % initiate the structure passing to player
        info = struct('stage',0,'pot',pot,'cur_pos',cur_pos,'cur_pot',cur_pot,'first_pos',first_pos,'board_card',board_card,'hole_card',zeros(1,2),'active',active,'paid',paid,'history',history_pre,'su_info',su_info,'oppo_model',[]);
        
        while (cur_pos~=end_pos)
            if (active(cur_pos) == true)
                if (cur_pos == first_pos && start == true)
                    % must bet small blind
                    pot = pot + SB;
                    money(cur_pos) = money(cur_pos) - SB;
                    paid(cur_pos) = SB;
                else
                    pot = pot;
                    info.cur_pos = cur_pos;                    
                    info.cur_pot = cur_pot;
                    info.hole_card = hole_card(cur_pos,:);
                    info.active = active;
                    info.paid = paid;
                    
                    %% TODO : fill in the following function
                    su_info = StageUpdater(info);
 
                    info.su_info = su_info;
                    info.oppo = oppo_model(cur_pos);
                    
                    %% TODO : fill in the following function
                    decision = MakeDecision(info);
                    
                    tmp_bet(cur_pos) = decision;
                    if (decision == RAISE && raise_num == RAISE_LIMIT)
                        decision = CALL;
                    end
                    if (cur_pos == second_pos && start == true)
                        decision = RAISE;
                        start = false;
                    end

                    if (decision == CALL)  % call
                        pay = cur_pot - paid(cur_pos);
                        pot = pot + pay;
                        money(cur_pos) = money(cur_pos) - pay;
                        paid(cur_pos) = paid(cur_pos) + pay;
                    elseif (decision == RAISE)  % raise
                        raise_num = raise_num + 1;
                        end_pos = cur_pos;
                        pay = cur_pot - paid(cur_pos) + SBU;
                        pot = pot + pay;
                        money(cur_pos) = money(cur_pos) - pay;
                        paid(cur_pos) = paid(cur_pos) + pay;
                        cur_pot = cur_pot + SBU;
                    else  % fold
                        active(cur_pos) = false;
                    end
                end
            end

            cur_pos = cur_pos + 1;
            if (cur_pos > N)
                cur_pos = 1;    
            end
        end
        
        history.bet = [history.bet; tmp_bet];
        
        fprintf(fid, '\nAfter PRE-FLOP: \n\t');
        PrintGameInfo(fid,active,money,pot,0,hole_card);

        %--------------------  Post Flop Stage -------------------------
        
        for stage = 1:3
            % deal board cards
            if (stage == 1)  %% flop
                for i = 1:3
                    board_card(i) = all_cards(cur);
                    cur = cur + 1;
                end
            else
                board_card(stage+2) = all_cards(cur);
                cur = cur + 1;
            end            
                       
            % bet
            cur_pot = 0;
            raise_num = 0;
            paid = zeros(1,N);
            end_pos = -1;
            cur_pos = first_pos;
            start = true;
            tmp_bet = zeros(1,N);
                       
            info = struct('stage',stage,'pot',pot,'cur_pos',cur_pos,'cur_pot',cur_pot,'first_pos',first_pos,'board_card',board_card,'hole_card',zeros(1,2),'active',active,'paid',paid,'history',history_pre,'su_info',su_info,'oppo',[]);
            
            while (cur_pos~=end_pos)
                if (active(cur_pos) == true)
                    if (start == true)
                        end_pos = cur_pos; 
                        start = false;
                    end

                    info.pot = pot;
                    info.cur_pos = cur_pos;
                    info.cur_pot = cur_pot;                    
                    info.hole_card = hole_card(cur_pos,:);
                    info.active = active; 
                    info.paid = paid;
                    
                    %% TODO : fill in the following function
                    su_info = StageUpdater(info);
                    
                    info.su_info = su_info;
                    info.oppo = (oppo_model(cur_pos));
                    
                    %% TODO : fill in the following function
                    decision = MakeDecision(info); 
                    
                    if (decision == RAISE && raise_num > RAISE_LIMIT)
                        decision = CALL;
                    end
                    
                    tmp_bet(cur_pos) = decision;

                    if (decision == CALL)  % call or check
                        pay = cur_pot - paid(cur_pos);
                        pot = pot + pay;
                        money(cur_pos) = money(cur_pos) - pay;
                        paid(cur_pos) = paid(cur_pos) + pay;
                    elseif (decision == RAISE)  % raise or bet
                        raise_num = raise_num + 1;
                        end_pos = cur_pos;
                        pay = cur_pot - paid(cur_pos) + SBU;
                        pot = pot + pay;
                        money(cur_pos) = money(cur_pos) - pay;
                        paid(cur_pos) = paid(cur_pos) + pay;
                        cur_pot = cur_pot + SBU;
                    else  % fold
                        active(cur_pos) = false;
                    end
                end
                
                if (sum(active) == 1)
                    break;
                end 
                
                cur_pos = cur_pos + 1;
                if (cur_pos > N)
                    cur_pos = 1;
                end
                
            end
            
            history.bet = [history.bet;tmp_bet];
            
            if (stage == 1)
                fprintf(fid, '\nAfter FLOP: \n\t');
            elseif (stage == 2)
                fprintf(fid, '\nAfter TURN: \n\t');
            else
                fprintf(fid, '\nAfter RIVER: \n\t');
            end
            PrintGameInfo(fid,active,money,pot,0,hole_card,board_card);
            
            if (sum(active) == 1)
                disp('Game ends!');
                break;
            end
                
        end
        
        if (sum(active) == 1)
            winner = find(active, 1);
            money(winner) = money(winner) + pot;
            tmp_active = active * 0;
            showdown = false;
        else
            tmp_active = active;
            showdown = true;
            winner = compare_showdown(active,hole_card,board_card);
            money(winner) = money(winner) + pot;
        end
        
        remain = 4 - mod(size(history.bet,1),4);
        if (remain < 4)
            tmp_bet = zeros(1,N);
            for j = 1:remain
                history.bet = [history.bet;tmp_bet];
            end 
        end  
        
        history.showdown = [history.showdown;showdown];
        history.board = [history.board; board_card];
        history.hole = [history.hole; reshape(hole_card',1,2*N).*kron(tmp_active,[1,1])];
        history_pre = history;
        
        for i = 1:N
            %% TODO : fill in the following function
            oppo = UpdateOpponent(history);
            oppo_model(i) = mat2cell(oppo,size(oppo,1),size(oppo,2));
        end
        
        %%Neo
        analysis = fopen('analysis.txt','a');
        fprintf(analysis, '\n%s\n\t', num2str(winner));
        fclose(analysis);
        str = ['Player ', num2str(winner), ' WINS!!!'];
        fprintf(fid, '\n%s\n\t', str);
        PrintGameInfo(fid,active,money,pot,1,hole_card,board_card);
        % PrintGameInfo(1,board_card,active,money,pot);
        
    end
    
    % fclose(fid);

end

% Determine winner in showdown by comparing hand categories and high cards
% Note: Currently the function always returns a single winner, even in
% the case of tie hands. Should be modified to return a list of winners
% in case of tie, and they should split the pot.
function winner = compare_showdown(active, hole_card, board_card)
    final_card = [];
    for i = 1:size(active,2)        
        final_card = [final_card;[board_card hole_card(i,:)]];
    end 
    max_type = -1;
    max_card = -1;
    for i = 1:size(final_card,1)
        if (active(i) == true)
            card = final_card(i,:);
            [type highcard] = final_type(card);
            if (type > max_type)
                winner = i;
                max_type = type; 
                max_card = highcard;
            elseif (type == max_type)
                % JIM modified
                if (type == 1 || type == 2 || type == 6)
                    % When comparing two hands that are both one pair, two
                    % pairs, or full house, look at both high cards
                    if (highcard(1) > max_card(1) || (highcard(1) == max_card(1) && highcard(2) > max_card(2)))
                        winner = i;
                        max_card = highcard;
                    end 
                else
                    % All other tie hands are determined by single high
                    % card
                    if (highcard > max_card)
                        winner = i;
                        max_card = highcard;
                    end
                end
            end
            
        end
    end
end

%% hand category in the showdown:
%%   0 -- Junk
%%   1 -- One Pair
%%   2 -- Two Pair
%%   3 -- Three of a Kind
%%   4 -- Straight
%%   5 -- Flush
%%   6 -- Full House
%%   7 -- Four of a Kind
%%   8 -- Straight Flush
function [type highcard] = final_type(v)
    [ct highcard_ct] = cardtype(v);
    [sf highcard_sf] = sftype(v);
    
    if (ct <= 3)
        type = ct;
        highcard = highcard_ct;
    end
    
    if (sf == 8)
        type = 4; % straight
        highcard = highcard_sf;
    end
    
    if (sf == 5)
        type = 5; % flush
        highcard = highcard_sf;
    end
    
    if (ct == 4)
        type = 6; % full house
        highcard = highcard_ct;
    end
    
    if (ct == 5)
        type = 7; % four of a kind
        highcard = highcard_ct;
    end
    
    if (sf == 1)
        type = 8; % straight flush
        highcard = highcard_sf;
    end
    
end

% Create a cell array of card names according to the card index coding
% Used to pretty print hand info
function MakeCardNames()
    global CARDnames VALnames SUITnames
    N = ['2'; '3'; '4'; '5'; '6'; '7'; '8'; '9'; 'T'; 'J'; 'Q'; 'K'; 'A'];
    S = ['D'; 'C'; 'H'; 'S'];
    % Construct outer product of number-suit
    X = repmat(N(:).', [length(S) 1]);
    Y = repmat(S(:), [1 length(N)]);
    VALnames = N;
    SUITnames = S;
    CARDnames = cellstr([X(:) Y(:)]);
end

function namestr = CardName(card)
    global CARDnames
    val = floor(card/4)+2;
    suit = mod(card,4);
    namestr = CARDnames(card+1);
end

% Given the hole cards and board cards for a single hand,
% generate a string containing the card names, hole cards first
% followed by board cards.
% Note: board card list can contain -1 for undealt cards
function hname = HandName(hole_card, board_card)
    global CARDnames
    bcvalid = board_card(find(board_card ~= -1));
    bcnames = CARDnames(bcvalid+1);   % +1 because card indices range from 0 to 51
    hcnames = CARDnames(hole_card+1);
    hname = strcat(sprintf('%s ', hcnames{:}), ' |', sprintf(' %s', bcnames{:}));
end

% Given the hole cards and board cards for a single hand,
% generate strings containing the hand categories for N of a Kind
% and Straight-Flush, including high cards, which are listed by value only
% Note: board card list can contain -1 for undealt cards
function [Kname SFname] = HandCategory(hole_card, board_card)
    global VALnames Knames SFnames
    v = [hole_card board_card];
    [ct high_ct] = cardtype(v);
    highnames = VALnames(high_ct-1);     % -1 comes from fact that val is in range 2-14
    Kname = sprintf('%7s-%2s', Knames{ct+1}, highnames);
    [sf high_sf] = sftype(v);
    highnames = VALnames(high_sf-1);     % -1 comes from fact that val is in range 2-14
    SFname = sprintf('%8s-%s', SFnames{sf+1}, highnames);
end

% Create a list of post-flop hand category strings in a cell array, 
% one for each player. Each string is a combination of the K and SF 
% categories with their high cards, separated by a '|' 
% (e.g. K2-A|F3-T). A '*' is used for inactive players
function handCat = ListHandCategories(active, hole_card, board_card)
    handCat = cell(2, size(active,2));
    for i = 1:size(active,2)
        if active(i)
            [Kcat SFcat] = HandCategory(hole_card(i,:), board_card);
            handCat{1,i} = Kcat;
            handCat{2,i} = SFcat;
        else
            handCat{1,i} = '     **** ';
            handCat{2,i} = '     **** ';
        end
    end
end

% Given hole cards and board cards for a single hand, generate string
% containing name of final hand category, including high cards
function Fcat = FinalCategory(hole_card, board_card)
    global VALnames FHnames
    v = [hole_card board_card];
    [type highcard] = final_type(v);
    highnames = VALnames(highcard-1);     % -1 comes from fact that val is in range 2-14
    Fcat = sprintf('%5s-%2s', FHnames{type+1}, highnames);
end

% Create a list of final hand strings in a cell array, one for each player.
% A '*' is used for inactive players
function Fhands = ListFinalHands(active, hole_card, board_card)
    handCat = cell(1, size(active,2));
    for i = 1:size(active,2)
        if active(i)
            Fhands{i} = FinalCategory(hole_card(i,:), board_card);
        else
            Fhands{i} = '   **** ';
        end
    end
end

% Function to pretty print game state after each stage
% showdown = 1 at the showdown (after a winner has been determined)
function PrintGameInfo(fid, active, money, pot, showdown, hole_card, board_card)
    global CARDnames
    if (nargin == 7)
        bcvalid = board_card(find(board_card ~= -1));
        bcnames = CARDnames(bcvalid+1);   % +1 because card indices range from 0 to 51
        fprintf(fid, 'Board cards:\t');
        fprintf(fid, '%s\t', bcnames{:});
        fprintf(fid, '\n\t');
    end
    
    HClist = reshape(hole_card', numel(hole_card), 1);
    HCnames = CARDnames(HClist+1);   % +1 because card indices range from 0 to 51
    fprintf(fid, 'Hole cards:\t');
    fprintf(fid, '     %s-%s\t', HCnames{:});
    fprintf(fid, '\n\t');
 
    if (nargin == 7)
        if showdown
            % At end of game, show final hand categories
            Ftypes = ListFinalHands(active, hole_card, board_card);
            fprintf(fid, 'Final hands:\t');
            fprintf(fid, '%s\t', Ftypes{:});
            fprintf(fid, '\n\t');
        else
            % At an intermediate stage, show all hand categories
            Htypes = ListHandCategories(active, hole_card, board_card);
            fprintf(fid, 'K types:\t');
            fprintf(fid, '%s\t', Htypes{1,:});
            fprintf(fid, '\n\t');

            fprintf(fid, 'SF types:\t');
            fprintf(fid, '%s\t', Htypes{2,:});
            fprintf(fid, '\n\t');
        end
    end
    
    fprintf(fid, 'Player status:\t'); 
    fprintf(fid, '%d\t', active);
    fprintf(fid, '\n\t');
    
    fprintf(fid, 'Money left:\t'); 
    fprintf(fid, '%d\t%d\t', money);
    fprintf(fid, '\n');
    
    fprintf(fid, '\tPot:\t'); 
    fprintf(fid, '%d\n', pot);
end